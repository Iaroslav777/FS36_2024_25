import './App.css'
import Chat from "./Chat.jsx";


function App() {

	return (
	  <>
		  <Chat/>
	  </>
	)
}

export default App
